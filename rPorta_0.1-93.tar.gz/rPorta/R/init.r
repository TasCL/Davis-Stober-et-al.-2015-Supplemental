.onLoad <- function(libname, pkgname) {
#	library.dynam(package = pkgname)
#	library.dynam(package = "RPorta")
	
}

#Example:
#none needed
