function [avgBF, medianBF, BF] = AllSimStateTrace(Reps, num_subs, num_violate, A, b)

BF = zeros(Reps,1);

parfor i=1:Reps
    [agdata,agn] = GenerateDataStateTraceSim(num_subs, num_violate, A, b);
    [BF1] = VolumeRankPolytopeStateNew(10000,agdata,agn,A,b);
    BF(i,1) = BF1;
end

avgBF = mean(BF);
medianBF = median(BF);

end

