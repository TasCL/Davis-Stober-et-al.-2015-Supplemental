function [agdata,agn,final_data] = GenerateDataStateTraceSimMinH(num_subs, num_violate, A, b)

data = zeros(num_subs,24);

%create individuals that satisfy model

%P = rand(1000000,24);
%k=1;
%for i=1:1000000
%    K = A*P(i,:)';
%    L = K<=b;
%    if (sum(L) == size(A,1));
%        data(k,:) = P(i,:);
%        k = k+1;
%    end
%end

%maximum heterogenus population
%data = data(1:num_subs,:);

%maximum homogenous population
data = repmat([.8 .82 .84 .86 .88 .9 .8 .82 .84 .86 .88 .9 .8 .82 .84 .86 .88 .9 .8 .82 .84 .86 .88 .9], num_subs,1);

%create individuals that violate model

data1 = zeros(num_violate,24);
P1 = rand(10000,24);
k=1;
for i=1:10000
    K = A*P1(i,:)';
    L = K<=b;
    if (sum(L) ~= size(A,1));
        data1(k,:) = P1(i,:);
        k = k+1;
    end
end

%maximum heterogenus population
data1 = data1(1:num_violate,:);

%maximum homogenous violation

%data1 = repmat([.95 .85 .80 .75 .70 .65 .95 .85 .80 .75 .70 .65 .95 .85 .80 .75 .70 .65 .95 .85 .80 .75 .70 .65], num_violate,1);

%put everything together

total_data = [data; data1];

num_subs_total = num_subs+num_violate;

final_data = binornd(100,total_data);

agdata = sum(final_data,1);
agn = ones(1,24)*num_subs_total*100;


end
