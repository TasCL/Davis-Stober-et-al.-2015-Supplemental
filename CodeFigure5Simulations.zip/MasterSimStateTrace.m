function [BF_list, BF_listh] = MasterSimStateTrace(BIGA,b,q)

tic
%These values are worst-case, maximum heterogenity

BF_list = zeros(q,15);

[~, ~, BF] = AllSimStateTrace(q, 14, 1, BIGA, b);
BF_list(:,1) = BF;

[~, ~, BF] = AllSimStateTrace(q, 13, 2, BIGA, b);
BF_list(:,2) = BF;

[~, ~, BF] = AllSimStateTrace(q, 12, 3, BIGA, b);
BF_list(:,3) = BF;

[~, ~, BF] = AllSimStateTrace(q, 11, 4, BIGA, b);
BF_list(:,4) = BF;

[~, ~, BF] = AllSimStateTrace(q, 10, 5, BIGA, b);
BF_list(:,5) = BF;

[~, ~, BF] = AllSimStateTrace(q, 9, 6, BIGA, b);
BF_list(:,6) = BF;

[~, ~, BF] = AllSimStateTrace(q, 8, 7, BIGA, b);
BF_list(:,7) = BF;

[~, ~, BF] = AllSimStateTrace(q, 7, 8, BIGA, b);
BF_list(:,8) = BF;

[~, ~, BF] = AllSimStateTrace(q, 6, 9, BIGA, b);
BF_list(:,9) = BF;

[~, ~, BF] = AllSimStateTrace(q, 5, 10, BIGA, b);
BF_list(:,10) = BF;

[~, ~, BF] = AllSimStateTrace(q, 4, 11, BIGA, b);
BF_list(:,11) = BF;

[~, ~, BF] = AllSimStateTrace(q, 3, 12, BIGA, b);
BF_list(:,12) = BF;

[~, ~, BF] = AllSimStateTrace(q, 2, 13, BIGA, b);
BF_list(:,13) = BF;

[~, ~, BF] = AllSimStateTrace(q, 1, 14, BIGA, b);
BF_list(:,14) = BF;

[~, ~, BF] = AllSimStateTrace(q, 0, 15, BIGA, b);
BF_list(:,15) = BF;


%These values are best-case, minimum heterogenity



BF_listh = zeros(q,15);

[~, ~, BF] = AllSimStateTrace1(q, 14, 1, BIGA, b);
BF_listh(:,1) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 13, 2, BIGA, b);
BF_listh(:,2) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 12, 3, BIGA, b);
BF_listh(:,3) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 11, 4, BIGA, b);
BF_listh(:,4) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 10, 5, BIGA, b);
BF_listh(:,5) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 9, 6, BIGA, b);
BF_listh(:,6) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 8, 7, BIGA, b);
BF_listh(:,7) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 7, 8, BIGA, b);
BF_listh(:,8) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 6, 9, BIGA, b);
BF_listh(:,9) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 5, 10, BIGA, b);
BF_listh(:,10) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 4, 11, BIGA, b);
BF_listh(:,11) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 3, 12, BIGA, b);
BF_listh(:,12) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 2, 13, BIGA, b);
BF_listh(:,13) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 1, 14, BIGA, b);
BF_listh(:,14) = BF;

[~, ~, BF] = AllSimStateTrace1(q, 0, 15, BIGA, b);
BF_listh(:,15) = BF;



toc



end






