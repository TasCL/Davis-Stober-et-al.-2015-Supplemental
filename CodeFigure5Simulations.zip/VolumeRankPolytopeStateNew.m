function [BF, final_volume] = VolumeRankPolytopeStateNew(NumSamples,data,n,A,b)

%load StateTrace.mat

R = A; %#ok<NODEF>
Rankfacets = R;
Rb = b; %#ok<NODEF>
Rankb = Rb;


dim = size(Rankfacets,2);
aparm = data + 1;
bparm = n-data+1;
Samples = zeros(NumSamples,dim);

parfor i=1:NumSamples
    Samples(i,:) = betarnd(aparm, bparm);
     %Samples(i,:) = rand(1,dim);
end
 


volume = 0;

for i = 1:NumSamples
    K = Rankfacets*Samples(i,:)';
    L = K<=Rankb;
    if (sum(L) == size(A,1));
        volume = volume + 1;
    end
end


final_volume = volume/NumSamples;

%For smaller polytope, the volume is .00003.  This gives a BF of 2088,
%approx.  Need to use BigA and Bigb files.

% .0006 is the estimated volume of larger polytope from qhull and my own 
%  Monte Carlo estimates




%Calculate BayesFactors
BF = final_volume/(.0006);

end

    