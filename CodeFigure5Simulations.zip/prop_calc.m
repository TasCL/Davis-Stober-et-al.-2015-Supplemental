function [prop]=prop_calc(X)

k = size(X,1);

Z = zeros(k,15);


for i=1:k
    for j=1:15
        if X(i,j) <= 1
            Z(i,j) = 1;
        end
    end
end

c=sum(Z,1);

prop = (1/k)*c;

end
